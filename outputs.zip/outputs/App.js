import React, { Component } from 'react';
import profilePic from "./spl ex pic 2.png";
import react from "./react.jpg";
import Api from "./api.jpg";
import Os from "./os.jpg";


class MyProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showMore: false
    };
  }

  toggleBio = () => {
    this.setState({ showMore: !this.state.showMore });
  };

  render() {
    return (
      <div style={{ textAlign: 'center', padding: '20px' }}>
        <img src={profilePic} alt="Profile" style={{ width: '150px', borderRadius: '50%' }} />
        <h1>sai kavya dasari</h1>
        <button onClick={this.toggleBio} style={{ backgroundColor: '#28a745', color: '#fff', padding: '10px', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
          {this.state.showMore ? 'Show Less' : 'Read More'}
        </button>
        {this.state.showMore && (
          <p style={{ padding: '10px', maxWidth: '600px', margin: 'auto' }}>
            Hello! I am sai kavya dasari, Dynamic and detail-oriented professional with over 2.5 years of handson experience in software development, MES implementation, and technical documentation.
          </p>
        )}
        
        <h2>Projects</h2>
        <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', margin: '20px' }}>
          <div>
            <img src={react} alt="react" style={{ width: '150px', height: '100px' }} />
            <h3>React</h3>
            <p>React is a JavaScript library for building user interfaces. React is used to build single-page applications. React allows us to create reusable UI components</p>
            <a href="#react">Project Link</a>
          </div>
          <div>
            <img src={Api} alt="Api" style={{ width: '150px', height: '100px' }} />
            <h3>Api</h3>
            <p>A document or standard that describes how to build such a connection or interface is called an API specification. A computer system that meets this standard is said to implement or expose an API. </p>
            <a href="#Api">Project Link</a>
          </div>
          <div>
            <img src={Os} alt="Os" style={{ width: '150px', height: '100px' }} />
            <h3>Os</h3>
            <p> Explore the architecture, features, and examples of various operating systems such as Linux, Windows.</p>
            <a href="#Os">Project Link</a>
          </div>
        </div>
        
        <h2>Connect with me!!!</h2>
        <div style={{ fontSize: '24px' }}>
          <a href="mailto:saikavyadasari@gmail.com" style={{ margin: '0 10px' }}>📧</a>
          <a href="https://github.com/saikavyadasari" style={{ margin: '0 10px' }}>🐱</a>
          <a href="https://www.linkedin.com/in/kavya-dasari-b293041b4" style={{ margin: '0 10px' }}>🔗</a>
        </div>
      </div>
    );
  }
}

export default MyProfile;